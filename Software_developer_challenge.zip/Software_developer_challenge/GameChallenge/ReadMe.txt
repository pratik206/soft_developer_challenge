Required installation 
node.js
npm
socket.io
express

How to run

Step 1: go to command promot
Step 2 run the following code 

node directory/server.js

Step 3: Open the borwser and type the following 
localhost:3000

Step 4; open another browser tab and type the followin
localhost:3000

Enjoy playing!