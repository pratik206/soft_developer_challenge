#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<string.h>

int main()
{
    int Rock=1;
    int Paper=2;
    int Scissor=3;
    int i;
    int Playerscore =0;
    int Computerscore =0;
    int choice;
    char name[15];
    srand(time(NULL));
    printf("Enter a Player name please:");
    gets(name);
    printf("%s is Playing\n",name);
    printf("Rock= 1, Paper= 2, Scissor= 3\n");

    for(i=0;i<5;i++){
        printf("Enter your choice:");
        scanf("%d",&choice);
            int computer=rand()%3+1;
            if(choice==1){
                if(computer==1){
                    printf("Draw\n");
                }
                if(computer==2){
                    printf("Computer Wins!\n");
                    Computerscore= Computerscore + 1;
                }
                if(computer==3){
                    printf("Player Wins\n");
                    Playerscore = Playerscore + 1;
                }
            }
              else  if(choice==2){
                    if(computer==2){
                        printf("Draw\n");
                    }
                    if(computer==3){
                        printf("Player Wins!\n");
                        Playerscore = Playerscore + 1;
                    }
                    if(computer==1){
                        printf("Computer Wins!\n");
                        Computerscore= Computerscore + 1;
                    }
                }
                else if(choice==3){
                    if(computer==3){
                        printf("Draw\n");
                    }
                    if(computer==2){
                        printf("Computer Wins!\n");
                        Computerscore= Computerscore + 1;
                    }
                    if(computer==1){
                        printf("Player Wins!\n");
                        Playerscore = Playerscore + 1;

                    }
                }
        else{
            printf("Wrong Answer\n");
            break;
        }

            }
            if(Computerscore > Playerscore ){
                printf("Computer wins %d to %d\n",Computerscore,Playerscore);
            }
            else if(Computerscore < Playerscore ){
                printf("Player wins %d to %d\n",Playerscore,Computerscore);
            }
           else if(Computerscore = Playerscore ){
                printf("No winner it is a draw!\n");
            }



    return 0;
}
